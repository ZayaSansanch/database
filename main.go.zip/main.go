package main

import (
	"database/sql"
	"fmt"

	"github.com/brianvoe/gofakeit/v6"
	_ "github.com/mattn/go-sqlite3"
)

type User struct {
	ID       int
	Login    string
	Email    string
	Password string
}

func main() {
	db, err := sql.Open("sqlite3", "data.sql")
	if err != nil {
		panic(err)
	}
	defer db.Close()

	var (
		login    = gofakeit.Username()
		email    = gofakeit.Email()
		password = gofakeit.Password(true, true, true, true, false, 8)
	)

	_, err = db.Exec("INSERT INTO users (login, email, password) VALUES ($1, $2, $3)", login, email, password)
	if err != nil {
		panic(err)
	}

	rows, err := db.Query("SELECT id, login, email, password FROM users")
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	users := make([]User, 0)

	for rows.Next() {
		var u User
		err := rows.Scan(&u.ID, &u.Login, &u.Email, &u.Password)
		if err != nil {
			fmt.Println(err)
			continue
		}
		users = append(users, u)
	}

	for _, u := range users {
		fmt.Println(u.ID, u.Email, u.Login, u.Password)
	}
}
